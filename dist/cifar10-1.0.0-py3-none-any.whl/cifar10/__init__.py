from cifar10.cifar10 import *

__version__ = "1.0.0"
